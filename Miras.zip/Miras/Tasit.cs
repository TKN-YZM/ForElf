﻿using System; 

namespace Miras
{
    public class Tasit
    {
        public string marka = "Ford";

        public virtual void korna() 
        {
            Console.WriteLine("Düt düt");
        }
    }
}
