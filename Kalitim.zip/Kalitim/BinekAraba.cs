﻿using System; 

namespace Kalitim
{
    public class BinekAraba : Araba
    {
        public int koltuk = 5;

        // korna --> bip bip

        public override void korna() 
        {
            Console.WriteLine("bip bip");
        }
    }
}
