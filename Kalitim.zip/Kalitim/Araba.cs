﻿using System; 

namespace Kalitim
{
    public class Araba : Tasit // Tasittan türetilen araba
    {
        public string model;
        public Araba() 
        {
            model = "Mustang";
        }

        public Araba(string yeniModel)
        {
            model = yeniModel;
        }

        public override void korna()
        {
            Console.WriteLine("na ni");
        }
    }
}
