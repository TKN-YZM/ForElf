﻿namespace Lab8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnOrnek_Click(object sender, EventArgs e)
        {
            //this.BackColor = Color.Red; 
            //BackColor = Color.Teal;

            //button1.Text = "DENEME";

            if (comboBox1.SelectedIndex == 0) 
                MessageBox.Show("İlkokulmuş");
            else if (comboBox1.SelectedIndex == 5)
                MessageBox.Show("Oo doktora");
            else
                MessageBox.Show("indeks dışı");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //label1.Text = "NAME: ";
            //label2.Text = "SURNAME: ";
            btnOrnek.Visible = true; 
            MessageBox.Show("Merhaba " + textBox1.Text + " " + textBox2.Text + "\n Eğitim Durumu: " + comboBox1.SelectedIndex.ToString()); 


        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Text = "Ad: ";
            label2.Text = "Soyad: ";
            label3.Text = "Eğitim: ";

            textBox1.Text = "Ömer";
            textBox2.Text = "Güleç";

            Text = "YÜKLENDİ";
            btnOrnek.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                /*int carpim = 1;

                for (int i = 1; i <= int.Parse(textBox3.Text); i++)
                {
                    carpim = carpim * i;
                    //carpim *= i;
                }

                MessageBox.Show(textBox3.Text + " sayısının faktoriyeli = " + carpim);*/

                label5.Text = "";
                 
                for (int i = 0; i < 10; i++)
                {
                    //label5.Text += textBox3.Text + "\n";
                    label5.Text = label5.Text + "\n" + textBox3.Text;
                }

            }
            catch (Exception)
            {

                MessageBox.Show("Düzgün girin");
            }
            
        }
    }
}