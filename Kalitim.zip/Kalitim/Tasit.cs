﻿using System; 

namespace Kalitim
{
    public class Tasit // base class
    {
        public string marka = "Ford";
        public int motorGucu;

        public virtual void korna() 
        {
            Console.WriteLine("Düt düt");
        }
    } 
}
