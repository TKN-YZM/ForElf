﻿namespace Lab9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        } 

        private void btnTest_Click(object sender, EventArgs e)
        {
            //BackColor = Color.Teal;
            btnTest.BackColor = Color.Purple;
            MessageBox.Show("Merhaba");
            btnSonraki.Enabled = true;
        }

        private void btnSonraki_Click(object sender, EventArgs e)
        {
            if (btnTest.Visible == true)
                btnTest.Visible = false;
            else
                btnTest.Visible = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnSonraki.Enabled = false;
            textBox1.Text = "Ömer";
            textBox2.Text = "Güleç";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string adSoyad = textBox1.Text + " " + textBox2.Text; 
            int secim = comboBox1.SelectedIndex; 

            if (secim == 5 || secim == 6)
                MessageBox.Show("Merhaba " + adSoyad + "\n Seçim= " + comboBox1.Text + " İyi tatiller");
            else
                MessageBox.Show("Merhaba " + adSoyad + "\n Seçim= " + comboBox1.SelectedItem.ToString() + " İyi dersler"); 
        }
    }
}