﻿using System;

namespace Kalitim
{
    public class Program
    {
        static void Main(string[] args)
        {
            //Araba arb = new Araba();
            //arb.korna(); 


            //Console.WriteLine(arb.marka + " " + arb.model);


            /*BinekAraba bnk = new BinekAraba();
            bnk.model = "Transit";
            bnk.korna();
            Console.WriteLine(bnk.marka + " " +bnk.model);*/

            Calisan cls = new Calisan();
            cls.bilgiVer();

            Console.WriteLine("");

            Mudur mdr = new Mudur();
            mdr.bilgiVer();

            Console.WriteLine("");

            Isci isc = new Isci();
            isc.bilgiVer();



            Console.ReadLine();
        }
    }
}
