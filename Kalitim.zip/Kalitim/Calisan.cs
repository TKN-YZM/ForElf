﻿using System; 

namespace Kalitim
{
    public class Calisan
    {
        public int asgari = 100;

        public virtual double maas() 
        {
            return asgari;
        }

        public void bilgiVer() 
        {
            Console.WriteLine("Çalışan Maaş = " + maas());
        }
    }

    public class Mudur : Calisan 
    {

        public override double maas()
        {
            return base.maas() * 2;
        }

        public void bilgiVer()
        {
            Console.WriteLine("Müdür Maaş = " + maas());
        }
    }

    public class Isci : Calisan
    {
        public override double maas()
        {
            return base.maas() * 1.5;
        }

        public void bilgiVer()
        {
            Console.WriteLine("İşçi Maaş = " + maas());
        }
    }
}
